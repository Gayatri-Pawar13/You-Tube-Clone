const express = require("express");
const router = express.Router();
const Video = require("../models/Video");
const { verifyToken } = require("../middleware/authMiddleware");
const { v4: uuidv4 } = require("uuid");

// ✅ Upload a new video
router.post("/", verifyToken, async (req, res) => {
  try {
    const {
      title,
      thumbnailUrl,
      videoUrl,
      description,
      channelId,
      channelName,
      category,
    } = req.body;

    const newVideo = new Video({
      videoId: uuidv4(),
      title,
      thumbnailUrl,
      videoUrl,
      description,
      channelId,
      channelName,
      uploader: req.user.id,
      category,
      views: 0,
      likes: 0,
      dislikes: 0,
      uploadDate: new Date().toISOString(),
      comments: [],
    });

    await newVideo.save();
    res.status(201).json(newVideo);
  } catch (err) {
    res.status(500).json({ error: "Video upload failed" });
  }
});

// ✅ Get single video
router.get("/:id", async (req, res) => {
  try {
    const video = await Video.findOne({ videoId: req.params.id });
    if (!video) return res.status(404).json({ error: "Video not found" });
    res.json(video);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch video" });
  }
});

// ✅ Get videos uploaded by a specific user
router.get("/uploader/:userId", verifyToken, async (req, res) => {
  try {
    const videos = await Video.find({ uploader: req.params.userId });
    res.json(videos);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch uploader's videos" });
  }
});

// ✅ Edit a video
router.put("/:id", verifyToken, async (req, res) => {
  try {
    const updatedVideo = await Video.findOneAndUpdate(
      { videoId: req.params.id, uploader: req.user.id },
      req.body,
      { new: true }
    );
    res.json(updatedVideo);
  } catch (err) {
    res.status(500).json({ error: "Failed to update video" });
  }
});

// ✅ Delete a video
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    await Video.findOneAndDelete({
      videoId: req.params.id,
      uploader: req.user.id,
    });
    res.json({ message: "Video deleted" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete video" });
  }
});

// ✅ Search & filter videos
router.get("/", async (req, res) => {
  const { search, category } = req.query;
  let filter = {};

  if (search) {
    filter.title = { $regex: search, $options: "i" };
  }

  if (category) {
    filter.category = category;
  }

  try {
    const videos = await Video.find(filter);
    res.json(videos);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch videos" });
  }
});

// ✅ Add a comment to a video
router.post("/:id/comments", async (req, res) => {
  const { userId, text } = req.body;
  const videoId = req.params.id;

  try {
    const video = await Video.findOne({ videoId });
    if (!video) return res.status(404).json({ error: "Video not found" });

    const newComment = {
      commentId: `comment_${Date.now()}`,
      userId,
      text,
      timestamp: new Date(),
    };

    video.comments.push(newComment);
    await video.save();

    res.status(201).json(newComment);
  } catch (err) {
    res.status(500).json({ error: "Failed to add comment" });
  }
});

// ✅ Edit a comment
router.put("/:videoId/comments/:commentId", async (req, res) => {
  const { text } = req.body;

  try {
    const video = await Video.findOne({ videoId: req.params.videoId });
    if (!video) return res.status(404).json({ error: "Video not found" });

    const comment = video.comments.find(
      (c) => c.commentId === req.params.commentId
    );
    if (!comment) return res.status(404).json({ error: "Comment not found" });

    comment.text = text;
    await video.save();

    res.json({ message: "Comment updated", comment });
  } catch (err) {
    res.status(500).json({ error: "Failed to edit comment" });
  }
});

// ✅ Delete a comment
router.delete("/:videoId/comments/:commentId", async (req, res) => {
  try {
    const video = await Video.findOne({ videoId: req.params.videoId });
    if (!video) return res.status(404).json({ error: "Video not found" });

    video.comments = video.comments.filter(
      (c) => c.commentId !== req.params.commentId
    );
    await video.save();

    res.json({ message: "Comment deleted" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete comment" });
  }
});

module.exports = router;
