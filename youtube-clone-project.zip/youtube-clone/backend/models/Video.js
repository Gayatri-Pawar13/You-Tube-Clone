const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  commentId: String,
  userId: String,
  text: String,
  timestamp: { type: Date, default: Date.now },
});

const videoSchema = new mongoose.Schema({
  videoId: { type: String, required: true },
  title: String,
  thumbnailUrl: String,
  videoUrl: String,
  description: String,
  channelId: String,
  channelName: String,
  uploader: String, // userId
  category: String,
  views: Number,
  likes: Number,
  dislikes: Number,
  uploadDate: String,
  comments: [commentSchema],
});

module.exports = mongoose.model("Video", videoSchema);
