import { useState } from "react";
import axios from "axios";

const UploadPage = () => {
  const [formData, setFormData] = useState({
    title: "",
    thumbnailUrl: "",
    videoUrl: "",
    description: "",
    channelId: "",
    channelName: "",
    category: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleUpload = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post("http://localhost:5000/api/videos", formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert("Video uploaded successfully!");
    } catch (err) {
      console.error("Upload failed", err);
      alert("Failed to upload video");
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Upload a Video</h2>
      {["title", "thumbnailUrl", "videoUrl", "description", "channelId", "channelName", "category"].map((field) => (
        <input
          key={field}
          type="text"
          name={field}
          placeholder={field}
          value={formData[field]}
          onChange={handleChange}
          className="border w-full mb-2 px-3 py-2 rounded"
        />
      ))}
      <button
        onClick={handleUpload}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        Upload
      </button>
    </div>
  );
};

export default UploadPage;
