import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import CommentBox from "../components/CommentBox";
//import CommentList from "../components/CommentList";


const VideoPage = () => {
  const { id } = useParams(); // Get video ID from URL
  const [video, setVideo] = useState(null);

  useEffect(() => {
    const fetchVideo = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/videos/${id}`);
        setVideo(res.data);
      } catch (err) {
        console.error("Error fetching video:", err);
      }
    };  

    fetchVideo();
  }, [id]);

  if (!video) return <div className="p-4">Loading...</div>;

  return (
    <div className="p-4 max-w-4xl mx-auto">
      {/* Video Player */}
      <iframe
        className="w-full h-96 mb-4"
        src={video.videoUrl}
        title={video.title}
        allowFullScreen
      ></iframe>

      {/* Video Info */}
      <h2 className="text-2xl font-bold">{video.title}</h2>
      <p className="text-gray-600">Channel: {video.channelName}</p>
      <p className="mt-2 text-sm">{video.description}</p>

      {/* Likes & Dislikes */}
      <div className="flex gap-4 my-4">
        <span>👍 {video.likes}</span>
        <span>👎 {video.dislikes}</span>
      </div>

      {/* Comment Box */}
      <CommentBox videoId={id} />

      {/* Comment List */}
      <CommentList comments={video.comments} videoId={id} />
    </div>
  );
};

export default VideoPage;
