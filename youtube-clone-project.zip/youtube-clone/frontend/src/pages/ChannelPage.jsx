import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ChannelPage = () => {
  const navigate = useNavigate();
  const [videos, setVideos] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!user || !token) {
      navigate("/auth"); // redirect if not logged in
    } else {
      fetchVideos();
    }
  }, []);

  const fetchVideos = async () => {
    try {
      const res = await axios.get(
        `http://localhost:5000/api/videos/uploader/${user._id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setVideos(res.data);
    } catch (err) {
      console.error("Failed to fetch channel videos", err);
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">My Uploaded Videos</h2>
      {videos.map((video) => (
        <div key={video.videoId} className="border p-2 rounded mb-4">
          <h3 className="font-semibold">{video.title}</h3>
          <p className="text-sm text-gray-600">{video.description}</p>
        </div>
      ))}
    </div>
  );
};

export default ChannelPage;
