import { useState } from "react";
import axios from "axios";

const Login = ({ setUser }) => {
  const [form, setForm] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", form);
      const { token, user } = res.data;
      localStorage.setItem("token", token);
      setUser(user);
      alert("Login successful!");
    } catch (error) {
      alert("Login failed");
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto mt-10 bg-white shadow-md rounded">
      <h2 className="text-xl font-bold mb-4">Login</h2>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input name="email" type="email" placeholder="Email" className="w-full border p-2" onChange={handleChange} />
        <input name="password" type="password" placeholder="Password" className="w-full border p-2" onChange={handleChange} />
        <button type="submit" className="bg-green-500 text-white w-full py-2">Login</button>
      </form>
    </div>
  );
};

export default Login;
