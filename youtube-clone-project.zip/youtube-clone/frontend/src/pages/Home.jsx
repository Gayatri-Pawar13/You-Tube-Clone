import { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const Home = () => {
  const [videos, setVideos] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/videos", {
          params: {
            search: searchTerm,
            category: selectedCategory,
          },
        });
        setVideos(res.data);
      } catch (err) {
        console.error("Failed to load videos", err);
      }
    };

    fetchVideos();
  }, [searchTerm, selectedCategory]);

  return (
    <div className="p-4">
      {/* Category Filter Buttons */}
      <div className="flex gap-2 flex-wrap mb-4">
        {["All", "React", "JavaScript", "Node", "MongoDB", "CSS"].map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category === "All" ? "" : category)}
            className={`px-4 py-1 rounded-full ${
              selectedCategory === category ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-700"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Video Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {videos.map((video) => (
          <Link
            to={`/video/${video.videoId}`}
            key={video.videoId}
            className="border rounded shadow hover:shadow-md transition"
          >
            <img
              src={video.thumbnailUrl}
              alt={video.title}
              className="w-full h-40 object-cover rounded-t"
            />
            <div className="p-2">
              <h3 className="text-lg font-semibold">{video.title}</h3>
              <p className="text-sm text-gray-500">{video.channelName}</p>
              <p className="text-sm text-gray-400">{video.views} views</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Home;
