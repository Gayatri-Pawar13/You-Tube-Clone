import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import VideoPage from "./pages/VideoPage";
import ChannelPage from "./pages/ChannelPage";
import Header from "./components/Header";
import { SearchContextProvider } from "./context/SearchContextProvider"; // ✅ Correct import
import UploadPage from "./pages/UploadPage";
import AuthPage from "./pages/AuthPage";
import NotFound from "./pages/NotFound";

const App = () => {
  return (
    <SearchContextProvider> {/* ✅ Fixed here */}
      <Router>
        {/* Global Header */}
        <Header />

        {/* Page Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/video/:id" element={<VideoPage />} />
          <Route path="/channel" element={<ChannelPage />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </SearchContextProvider>
  );
};

export default App;
