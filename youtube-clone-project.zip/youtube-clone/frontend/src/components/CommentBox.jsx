import { useState } from "react";
import axios from "axios";

const CommentBox = ({ videoId }) => {
  const [comment, setComment] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`http://localhost:5000/api/videos/${videoId}/comments`, {
        userId: "user01", // ✅ replace with dynamic logged-in user
        text: comment,
      });
      setComment("");
      window.location.reload(); // simple refresh to show new comment
    } catch (err) {
      console.error("Failed to post comment", err);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="my-4">
      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Add a comment..."
        className="w-full p-2 border rounded"
      />
      <button
        type="submit"
        className="mt-2 bg-blue-600 text-white px-4 py-1 rounded"
      >
        Comment
      </button>
    </form>
  );
};

export default CommentBox;
