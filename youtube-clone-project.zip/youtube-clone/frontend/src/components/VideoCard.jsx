const VideoCard = ({ video }) => {
  return (
    <div className="w-full sm:w-1/2 md:w-1/3 lg:w-1/4 p-2">
      <div className="shadow-md rounded">
        <img src={video.thumbnailUrl} alt={video.title} className="w-full h-48 object-cover" />
        <div className="p-2">
          <h3 className="font-bold text-sm">{video.title}</h3>
          <p className="text-gray-500 text-xs">{video.uploader}</p>
          <p className="text-gray-500 text-xs">{video.views} views</p>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
