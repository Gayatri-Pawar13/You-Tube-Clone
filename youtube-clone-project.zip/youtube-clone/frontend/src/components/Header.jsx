import { useContext } from "react";
import { SearchContext } from "../context/SearchContextProvider";
import { Link, useNavigate } from "react-router-dom";

const Header = ({ toggleSidebar }) => {
  const { searchTerm, setSearchTerm } = useContext(SearchContext);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/auth");
  };

  return (
    <header className="flex justify-between items-center p-4 bg-white shadow-md">
      {/* Left: Sidebar Toggle + Logo */}
      <div className="flex items-center gap-4">
        <button onClick={toggleSidebar} className="text-xl font-bold">
          ☰
        </button>
        <Link to="/" className="flex items-center gap-1 text-red-600 text-xl font-bold">
          ▶️ <span>YouTube</span>
        </Link>
      </div>

      {/* Center: Search Input */}
      <input
        type="text"
        placeholder="Search"
        className="border px-4 py-1 rounded-md w-1/2"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {/* Right: User Info or Sign In */}
      {user ? (
        <div className="flex items-center gap-3">
          <img
            src={user.avatar}
            alt="avatar"
            className="w-8 h-8 rounded-full object-cover"
          />
          <span className="text-sm font-medium">{user.username}</span>
          <button
            onClick={handleLogout}
            className="bg-red-500 text-white px-3 py-1 rounded text-sm"
          >
            Logout
          </button>
        </div>
      ) : (
        <button
          className="bg-blue-500 text-white px-4 py-1 rounded"
          onClick={() => navigate("/auth")}
        >
          Sign In
        </button>
      )}
    </header>
  );
};

export default Header;
