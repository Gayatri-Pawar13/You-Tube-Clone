const Sidebar = ({ isOpen }) => {
  return (
    <aside className={`w-60 bg-gray-100 p-4 h-screen transition-transform duration-300 ${isOpen ? "translate-x-0" : "-translate-x-full"} fixed z-10`}>
      <ul className="space-y-4">
        <li>Home</li>
        <li>Trending</li>
        <li>Subscriptions</li>
        <li>Library</li>
      </ul>
    </aside>
  );
};

export default Sidebar;
